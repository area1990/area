/**
 * 
 */
package com.bazarlist.service.dec;

import com.bazarlist.model.Hall;

/**
 * @author JK
 *
 */
public interface IHallService {

	void save(Hall entity) throws Exception;


}
