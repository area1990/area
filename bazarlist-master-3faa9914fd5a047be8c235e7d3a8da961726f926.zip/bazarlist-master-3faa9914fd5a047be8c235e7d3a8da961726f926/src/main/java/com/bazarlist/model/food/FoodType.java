/**
 * 
 */
package com.bazarlist.model.food;

/**
 * @author JK
 *
 */
public enum FoodType {
	rice,
	mainFood,
	desert;
}
